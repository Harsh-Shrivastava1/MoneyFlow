package com.moneyflow.app.ui.goals

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.moneyflow.app.data.entities.SavingGoal
import com.moneyflow.app.data.entities.SavingRecord
import com.moneyflow.app.data.repository.GoalRepository
import com.moneyflow.app.ui.base.BaseViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GoalViewModel(
    private val repository: GoalRepository
) : BaseViewModel() {

    val goals: StateFlow<List<SavingGoal>> = repository.allGoals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addGoal(title: String, targetAmount: Double, deadline: Long) {
        viewModelScope.launch {
            repository.insert(
                SavingGoal(
                    title = title,
                    targetAmount = targetAmount,
                    deadline = deadline
                )
            )
        }
    }

    fun addSavings(goal: SavingGoal, amount: Double) {
        viewModelScope.launch {
            val newSavedAmount = goal.savedAmount + amount
            val updatedGoal = goal.copy(savedAmount = newSavedAmount)
            repository.update(updatedGoal)
            
            repository.insertRecord(
                SavingRecord(
                    goalId = goal.id,
                    amount = amount,
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    fun getGoal(id: Long): StateFlow<SavingGoal?> {
        return repository.getGoalById(id)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    }
}

class GoalViewModelFactory(private val repository: GoalRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(GoalViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return GoalViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
