package com.moneyflow.app.ui.goals

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.moneyflow.app.data.entities.SavingGoal
import com.moneyflow.app.databinding.ItemGoalBinding
import java.text.NumberFormat
import java.util.Locale

class GoalAdapter(
    private val onItemClick: (SavingGoal) -> Unit
) : ListAdapter<SavingGoal, GoalAdapter.GoalViewHolder>(GoalDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GoalViewHolder {
        val binding = ItemGoalBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return GoalViewHolder(binding)
    }

    override fun onBindViewHolder(holder: GoalViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class GoalViewHolder(private val binding: ItemGoalBinding) :
        RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val pos = adapterPosition
                if (pos != RecyclerView.NO_POSITION) {
                    onItemClick(getItem(pos))
                }
            }
        }

        fun bind(goal: SavingGoal) {
            // Use XML IDs correctly
            binding.tvGoalTitle.text = goal.title

            val progressPercent =
                if (goal.targetAmount > 0)
                    ((goal.savedAmount / goal.targetAmount) * 100).toInt()
                else 0

            // Set progress
            binding.progressIndicator.progress = progressPercent
            binding.tvPercentage.text = "$progressPercent%"

            // Currency formatting
            val format = NumberFormat.getCurrencyInstance(Locale.US)
            binding.tvGoalAmount.text =
                "${format.format(goal.savedAmount)} / ${format.format(goal.targetAmount)}"
        }
    }

    class GoalDiffCallback : DiffUtil.ItemCallback<SavingGoal>() {
        override fun areItemsTheSame(oldItem: SavingGoal, newItem: SavingGoal): Boolean =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: SavingGoal, newItem: SavingGoal): Boolean =
            oldItem == newItem
    }
}
