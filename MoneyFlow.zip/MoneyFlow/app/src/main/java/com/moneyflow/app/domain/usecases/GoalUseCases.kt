package com.moneyflow.app.domain.usecases

import com.moneyflow.app.data.entities.SavingGoal
import com.moneyflow.app.data.entities.SavingRecord
import com.moneyflow.app.data.repository.GoalRepository
import kotlinx.coroutines.flow.Flow

class AddGoalUseCase(private val repository: GoalRepository) {
    suspend operator fun invoke(goal: SavingGoal) = repository.insert(goal)
}

class GetGoalsUseCase(private val repository: GoalRepository) {
    operator fun invoke(): Flow<List<SavingGoal>> = repository.allGoals
}

class GetGoalByIdUseCase(private val repository: GoalRepository) {
    operator fun invoke(id: Long): Flow<SavingGoal> = repository.getGoalById(id)
}

class UpdateGoalProgressUseCase(private val repository: GoalRepository) {
    suspend operator fun invoke(goal: SavingGoal, amountToAdd: Double) {
        val newSavedAmount = goal.savedAmount + amountToAdd
        val updatedGoal = goal.copy(savedAmount = newSavedAmount)
        repository.update(updatedGoal)
        
        val record = SavingRecord(
            goalId = goal.id,
            amount = amountToAdd,
            timestamp = System.currentTimeMillis()
        )
        repository.insertRecord(record)
    }
}

class DeleteGoalUseCase(private val repository: GoalRepository) {
    suspend operator fun invoke(goal: SavingGoal) = repository.delete(goal)
}

class GetGoalRecordsUseCase(private val repository: GoalRepository) {
    operator fun invoke(goalId: Long): Flow<List<SavingRecord>> = repository.getRecordsForGoal(goalId)
}
