package com.moneyflow.app.ui.analytics

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import com.moneyflow.app.MoneyFlowApplication
import com.moneyflow.app.databinding.FragmentAnalyticsBinding
import com.moneyflow.app.ui.base.BaseFragment
import com.moneyflow.app.ui.dashboard.DashboardViewModel
import com.moneyflow.app.ui.dashboard.DashboardViewModelFactory
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class AnalyticsFragment : BaseFragment<FragmentAnalyticsBinding>(
    FragmentAnalyticsBinding::inflate
) {

    private val viewModel: DashboardViewModel by viewModels {
        DashboardViewModelFactory(
            (requireActivity().application as MoneyFlowApplication).expenseRepository,
            (requireActivity().application as MoneyFlowApplication).goalRepository
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        // Simple implementation: Just show total stats for now as requested "Simple Charts"
        // In a real app, we'd use MPAndroidChart or similar.
        // Here we'll just show a summary text.
        
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.totalExpense.collectLatest { total ->
                binding.tvTotalSpent.text = "Total Spent: $total"
            }
        }
    }
}
