package com.moneyflow.app.ui.goals

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.moneyflow.app.MoneyFlowApplication
import com.moneyflow.app.databinding.BottomSheetAddGoalBinding

class AddGoalBottomSheet : BottomSheetDialogFragment() {

    private var _binding: BottomSheetAddGoalBinding? = null
    private val binding get() = _binding!!

    private val viewModel: GoalViewModel by viewModels {
        GoalViewModelFactory(
            (requireActivity().application as MoneyFlowApplication).goalRepository
        )
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomSheetAddGoalBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnSaveGoal.setOnClickListener {

            val title = binding.etGoalTitle.text.toString()
            val targetAmountStr = binding.etTargetAmount.text.toString()

            if (title.isBlank() || targetAmountStr.isBlank()) {
                return@setOnClickListener
            }

            val targetAmount = targetAmountStr.toDoubleOrNull() ?: return@setOnClickListener

            viewModel.addGoal(
                title,
                targetAmount,
                System.currentTimeMillis() + 86400000L * 30
            )

            dismiss()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
