package com.moneyflow.app.ui.goals

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import com.moneyflow.app.MoneyFlowApplication
import com.moneyflow.app.databinding.FragmentGoalDetailBinding
import com.moneyflow.app.ui.base.BaseFragment
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

class GoalDetailFragment : BaseFragment<FragmentGoalDetailBinding>(
    FragmentGoalDetailBinding::inflate
) {

    private val viewModel: GoalViewModel by viewModels {
        GoalViewModelFactory(
            (requireActivity().application as MoneyFlowApplication).goalRepository
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val goalId = arguments?.getLong("goalId") ?: return

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.getGoal(goalId).collectLatest { goal ->
                goal?.let {
                    binding.tvGoalTitle.text = it.title
                    
                    val progress = if (it.targetAmount > 0) {
                        ((it.savedAmount / it.targetAmount) * 100).toInt()
                    } else {
                        0
                    }
                    binding.progressDetail.progress = progress
                    binding.tvDetailPercentage.text = "$progress%"
                    
                    val format = NumberFormat.getCurrencyInstance(Locale.US)
                    binding.tvSavedAmount.text = "${format.format(it.savedAmount)} saved"
                    binding.tvTargetAmount.text = "of ${format.format(it.targetAmount)} goal"

                    binding.btnAddSavings.setOnClickListener { _ ->
                        AddSavingsBottomSheet(it).show(parentFragmentManager, "AddSavings")
                    }
                }
            }
        }
    }
}
