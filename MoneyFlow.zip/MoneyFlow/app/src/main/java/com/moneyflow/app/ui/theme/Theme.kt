package com.moneyflow.app.ui.theme

// Your app uses XML + ViewBinding.
// Jetpack Compose themes are not needed.
// This file stays empty or can store simple constants if required.

object MoneyFlowTheme {
    // Add color constants or theme helpers here if needed.
}
