package com.moneyflow.app.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.moneyflow.app.data.dao.ExpenseDao
import com.moneyflow.app.data.dao.GoalDao
import com.moneyflow.app.data.entities.Expense
import com.moneyflow.app.data.entities.SavingGoal
import com.moneyflow.app.data.entities.SavingRecord

@Database(
    entities = [Expense::class, SavingGoal::class, SavingRecord::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun expenseDao(): ExpenseDao
    abstract fun goalDao(): GoalDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "moneyflow_database"
                )
                .fallbackToDestructiveMigration() // For simplicity in dev, but prompt asked for migrations support. 
                // Since it's v1, no migration needed yet.
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
