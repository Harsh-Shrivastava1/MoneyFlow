package com.moneyflow.app

import android.app.Application
import com.moneyflow.app.data.database.AppDatabase
import com.moneyflow.app.data.repository.ExpenseRepository
import com.moneyflow.app.data.repository.GoalRepository

class MoneyFlowApplication : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    val expenseRepository by lazy { ExpenseRepository(database.expenseDao()) }
    val goalRepository by lazy { GoalRepository(database.goalDao()) }
}
