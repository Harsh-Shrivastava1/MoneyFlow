package com.moneyflow.app.ui.theme

// This project does not use Jetpack Compose.
// Typography for XML-based UI is defined in res/values.
// Keeping this file empty to avoid Compose errors.

object AppTypography
