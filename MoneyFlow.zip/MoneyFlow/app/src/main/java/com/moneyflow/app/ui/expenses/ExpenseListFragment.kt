package com.moneyflow.app.ui.expenses

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.moneyflow.app.MoneyFlowApplication
import com.moneyflow.app.R
import com.moneyflow.app.databinding.FragmentExpenseListBinding
import com.moneyflow.app.ui.base.BaseFragment
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ExpenseListFragment : BaseFragment<FragmentExpenseListBinding>(
    FragmentExpenseListBinding::inflate
) {

    private val viewModel: ExpenseViewModel by viewModels {
        ExpenseViewModelFactory(
            (requireActivity().application as MoneyFlowApplication).expenseRepository
        )
    }

    private lateinit var adapter: ExpenseAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupFab()
        observeData()
    }

    private fun setupRecyclerView() {
        adapter = ExpenseAdapter { expense ->
            // Handle item click if needed
        }
        binding.rvExpenses.adapter = adapter

        val itemTouchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            0,
            ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                val expense = adapter.currentList[position]
                
                if (direction == ItemTouchHelper.LEFT) {
                    // Delete
                    viewModel.deleteExpense(expense)
                } else {
                    // Edit (Not fully implemented in this phase, just restore for now or show message)
                    // Ideally navigate to edit sheet with arguments
                    adapter.notifyItemChanged(position) // Reset swipe
                }
            }

            override fun onChildDraw(
                c: Canvas,
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                dX: Float,
                dY: Float,
                actionState: Int,
                isCurrentlyActive: Boolean
            ) {
                val background = if (dX > 0) {
                    ColorDrawable(Color.BLUE) // Edit
                } else {
                    ColorDrawable(Color.RED) // Delete
                }
                
                val itemView = viewHolder.itemView
                background.setBounds(
                    if (dX > 0) itemView.left else itemView.right + dX.toInt(),
                    itemView.top,
                    if (dX > 0) itemView.left + dX.toInt() else itemView.right,
                    itemView.bottom
                )
                background.draw(c)
                
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)
            }
        })
        itemTouchHelper.attachToRecyclerView(binding.rvExpenses)
    }

    private fun setupFab() {
        binding.fabAddExpense.setOnClickListener {
            findNavController().navigate(R.id.action_expenseListFragment_to_addEditExpenseBottomSheet)
        }
    }

    private fun observeData() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.expenses.collectLatest { expenses ->
                adapter.submitList(expenses)
                binding.layoutEmpty.root.visibility = if (expenses.isEmpty()) View.VISIBLE else View.GONE
                binding.layoutEmpty.tvEmptyMessage.text = "Tap the + button to add your first expense"
            }
        }
    }
}
