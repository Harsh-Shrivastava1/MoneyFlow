package com.moneyflow.app.ui.goals

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.moneyflow.app.MoneyFlowApplication
import com.moneyflow.app.R
import com.moneyflow.app.databinding.FragmentGoalListBinding
import com.moneyflow.app.ui.base.BaseFragment
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class GoalListFragment : BaseFragment<FragmentGoalListBinding>(
    FragmentGoalListBinding::inflate
) {

    private val viewModel: GoalViewModel by viewModels {
        GoalViewModelFactory(
            (requireActivity().application as MoneyFlowApplication).goalRepository
        )
    }

    private lateinit var adapter: GoalAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupFab()
        observeData()
    }

    private fun setupRecyclerView() {
        adapter = GoalAdapter { goal ->
            val bundle = Bundle().apply {
                putLong("goalId", goal.id)
            }
            findNavController().navigate(R.id.action_goalListFragment_to_goalDetailFragment, bundle)
        }
        binding.rvGoals.adapter = adapter
    }

    private fun setupFab() {
        binding.fabAddGoal.setOnClickListener {
            findNavController().navigate(R.id.action_goalListFragment_to_addGoalBottomSheet)
        }
    }

    private fun observeData() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.goals.collectLatest { goals ->
                adapter.submitList(goals)
                binding.layoutEmpty.root.visibility = if (goals.isEmpty()) View.VISIBLE else View.GONE
                binding.layoutEmpty.tvEmptyMessage.text = "No saving goals yet. Start one by tapping +"
            }
        }
    }
}
