package com.moneyflow.app.domain.usecases

import com.moneyflow.app.data.entities.Expense
import com.moneyflow.app.data.repository.ExpenseRepository
import kotlinx.coroutines.flow.Flow

class AddExpenseUseCase(private val repository: ExpenseRepository) {
    suspend operator fun invoke(expense: Expense) = repository.insert(expense)
}

class GetExpensesUseCase(private val repository: ExpenseRepository) {
    operator fun invoke(): Flow<List<Expense>> = repository.allExpenses
}

class GetTotalExpenseUseCase(private val repository: ExpenseRepository) {
    operator fun invoke(): Flow<Double?> = repository.totalExpense
}

class DeleteExpenseUseCase(private val repository: ExpenseRepository) {
    suspend operator fun invoke(expense: Expense) = repository.delete(expense)
}

class UpdateExpenseUseCase(private val repository: ExpenseRepository) {
    suspend operator fun invoke(expense: Expense) = repository.update(expense)
}
