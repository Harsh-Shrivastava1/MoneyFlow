package com.moneyflow.app.utils

import android.content.Context
import android.content.SharedPreferences

class BudgetManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("budget_prefs", Context.MODE_PRIVATE)

    fun setMonthlyBudget(amount: Double) {
        prefs.edit().putFloat("monthly_budget", amount.toFloat()).apply()
    }

    fun getMonthlyBudget(): Double {
        return prefs.getFloat("monthly_budget", 0f).toDouble()
    }

    fun getBudgetProgress(currentExpense: Double): Int {
        val budget = getMonthlyBudget()
        if (budget <= 0) return 0
        return ((currentExpense / budget) * 100).toInt()
    }
}
