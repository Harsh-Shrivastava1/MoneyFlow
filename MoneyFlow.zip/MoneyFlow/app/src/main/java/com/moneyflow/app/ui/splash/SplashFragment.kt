package com.moneyflow.app.ui.splash

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.moneyflow.app.R
import com.moneyflow.app.databinding.FragmentSplashBinding
import com.moneyflow.app.ui.base.BaseFragment

class SplashFragment : BaseFragment<FragmentSplashBinding>(
    FragmentSplashBinding::inflate
) {
    override fun onResume() {
        super.onResume()
        
        // Animate Logo
        binding.tvLogo.animate()
            .alpha(1f)
            .scaleX(1.2f)
            .scaleY(1.2f)
            .setDuration(1000)
            .withEndAction {
                // Animate Underline
                binding.underline.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setDuration(500)
                    .withEndAction {
                        // Navigate after delay
                        Handler(Looper.getMainLooper()).postDelayed({
                            findNavController().navigate(R.id.action_splashFragment_to_introFragment)
                        }, 1000)
                    }
                    .start()
            }
            .start()
    }
}

