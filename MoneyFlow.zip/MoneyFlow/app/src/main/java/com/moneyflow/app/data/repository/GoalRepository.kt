package com.moneyflow.app.data.repository

import com.moneyflow.app.data.dao.GoalDao
import com.moneyflow.app.data.entities.SavingGoal
import com.moneyflow.app.data.entities.SavingRecord
import kotlinx.coroutines.flow.Flow

class GoalRepository(private val goalDao: GoalDao) {
    val allGoals: Flow<List<SavingGoal>> = goalDao.getAllGoals()

    fun getGoalById(id: Long): Flow<SavingGoal> = goalDao.getGoalById(id)

    suspend fun insert(goal: SavingGoal) {
        goalDao.insertGoal(goal)
    }

    suspend fun update(goal: SavingGoal) {
        goalDao.updateGoal(goal)
    }

    suspend fun delete(goal: SavingGoal) {
        goalDao.deleteGoal(goal)
    }

    suspend fun insertRecord(record: SavingRecord) {
        goalDao.insertRecord(record)
    }

    fun getRecordsForGoal(goalId: Long): Flow<List<SavingRecord>> = goalDao.getRecordsForGoal(goalId)
}
