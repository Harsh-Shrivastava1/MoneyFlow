package com.moneyflow.app.ui.dashboard

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.moneyflow.app.MoneyFlowApplication
import com.moneyflow.app.R
import com.moneyflow.app.databinding.FragmentDashboardBinding
import com.moneyflow.app.ui.base.BaseFragment
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

class DashboardFragment : BaseFragment<FragmentDashboardBinding>(
    FragmentDashboardBinding::inflate
) {

    private val viewModel: DashboardViewModel by viewModels {
        DashboardViewModelFactory(
            (requireActivity().application as MoneyFlowApplication).expenseRepository,
            (requireActivity().application as MoneyFlowApplication).goalRepository
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupClickListeners()
        observeData()
    }

    private fun setupClickListeners() {
        binding.cardExpenses.setOnClickListener {
            findNavController().navigate(R.id.action_dashboardFragment_to_expenseListFragment)
        }

        binding.cardSavings.setOnClickListener { // Changed from cardGoals to cardSavings if ID changed, but keeping consistent
            findNavController().navigate(R.id.action_dashboardFragment_to_goalListFragment)
        }
        
        binding.btnViewExpenses.setOnClickListener {
            findNavController().navigate(R.id.action_dashboardFragment_to_expenseListFragment)
        }

        binding.btnViewGoals.setOnClickListener {
            findNavController().navigate(R.id.action_dashboardFragment_to_goalListFragment)
        }
    }

    private fun observeData() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.totalExpense.collectLatest { total ->
                binding.tvTotalExpense.text = NumberFormat.getCurrencyInstance(Locale.US).format(total)
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.totalSavings.collectLatest { total ->
                binding.tvTotalSavings.text = NumberFormat.getCurrencyInstance(Locale.US).format(total)
            }
        }
        
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.smartInsight.collectLatest { insight ->
                binding.tvInsightText.text = insight
            }
        }
    }
}

