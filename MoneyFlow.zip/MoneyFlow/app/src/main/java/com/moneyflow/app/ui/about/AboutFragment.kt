package com.moneyflow.app.ui.about

import android.os.Bundle
import android.view.View
import androidx.navigation.fragment.findNavController
import com.moneyflow.app.R
import com.moneyflow.app.databinding.FragmentAboutBinding
import com.moneyflow.app.ui.base.BaseFragment

class AboutFragment : BaseFragment<FragmentAboutBinding>(
    FragmentAboutBinding::inflate
) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnContinue.setOnClickListener {
            findNavController().navigate(R.id.action_aboutFragment_to_dashboardFragment)
        }
    }
}

