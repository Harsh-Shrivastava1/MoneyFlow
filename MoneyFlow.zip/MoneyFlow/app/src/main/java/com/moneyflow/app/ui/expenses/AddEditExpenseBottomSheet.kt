package com.moneyflow.app.ui.expenses

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.chip.Chip
import com.moneyflow.app.MoneyFlowApplication
import com.moneyflow.app.databinding.BottomSheetAddExpenseBinding

class AddEditExpenseBottomSheet : BottomSheetDialogFragment() {

    private var _binding: BottomSheetAddExpenseBinding? = null
    private val binding get() = _binding!!

    private val viewModel: ExpenseViewModel by viewModels {
        ExpenseViewModelFactory(
            (requireActivity().application as MoneyFlowApplication).expenseRepository
        )
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomSheetAddExpenseBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnSave.setOnClickListener {
            val title = binding.etTitle.text.toString()
            val amountStr = binding.etAmount.text.toString()
            val chipId = binding.chipGroupCategory.checkedChipId
            
            if (title.isBlank() || amountStr.isBlank() || chipId == View.NO_ID) {
                // Show error
                return@setOnClickListener
            }

            val amount = amountStr.toDoubleOrNull() ?: return@setOnClickListener
            val category = binding.root.findViewById<Chip>(chipId).text.toString()

            viewModel.addExpense(title, amount, category)
            dismiss()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
