package com.moneyflow.app.ui.goals

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.moneyflow.app.MoneyFlowApplication
import com.moneyflow.app.databinding.BottomSheetAddSavingsBinding
import com.moneyflow.app.data.entities.SavingGoal

class AddSavingsBottomSheet(private val goal: SavingGoal) : BottomSheetDialogFragment() {

    private var _binding: BottomSheetAddSavingsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: GoalViewModel by viewModels {
        GoalViewModelFactory(
            (requireActivity().application as MoneyFlowApplication).goalRepository
        )
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomSheetAddSavingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnSave.setOnClickListener {
            val amountStr = binding.etAmount.text.toString()
            val amount = amountStr.toDoubleOrNull()
            
            if (amount != null && amount > 0) {
                viewModel.addSavings(goal, amount)
                dismiss()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
