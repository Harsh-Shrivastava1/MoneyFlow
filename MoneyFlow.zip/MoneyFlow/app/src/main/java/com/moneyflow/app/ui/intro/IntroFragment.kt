package com.moneyflow.app.ui.intro

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.moneyflow.app.R
import com.moneyflow.app.databinding.FragmentIntroBinding
import com.moneyflow.app.ui.base.BaseFragment

class IntroFragment : BaseFragment<FragmentIntroBinding>(
    FragmentIntroBinding::inflate
) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        // Initial state
        binding.tvAppName.alpha = 0f
        binding.tvAppName.translationY = 50f
        
        binding.tvTagline.alpha = 0f
        binding.tvTagline.translationY = 50f
        
        binding.btnContinue.alpha = 0f
        binding.btnContinue.translationY = 100f
        
        binding.btnAbout.alpha = 0f
        binding.btnAbout.translationY = 100f

        // Animate
        binding.tvAppName.animate().alpha(1f).translationY(0f).setDuration(800).setStartDelay(200).start()
        binding.tvTagline.animate().alpha(1f).translationY(0f).setDuration(800).setStartDelay(400).start()
        binding.btnContinue.animate().alpha(1f).translationY(0f).setDuration(800).setStartDelay(600).start()
        binding.btnAbout.animate().alpha(1f).translationY(0f).setDuration(800).setStartDelay(800).start()

        binding.btnContinue.setOnClickListener {
            findNavController().navigate(R.id.action_introFragment_to_dashboardFragment)
        }

        binding.btnAbout.setOnClickListener {
            findNavController().navigate(R.id.action_introFragment_to_aboutFragment)
        }
    }
}

