package com.moneyflow.app.data.dao

import androidx.room.*
import com.moneyflow.app.data.entities.SavingGoal
import com.moneyflow.app.data.entities.SavingRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface GoalDao {
    @Query("SELECT * FROM saving_goals ORDER BY deadline ASC")
    fun getAllGoals(): Flow<List<SavingGoal>>

    @Query("SELECT * FROM saving_goals WHERE id = :id")
    fun getGoalById(id: Long): Flow<SavingGoal>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: SavingGoal)

    @Update
    suspend fun updateGoal(goal: SavingGoal)

    @Delete
    suspend fun deleteGoal(goal: SavingGoal)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: SavingRecord)

    @Query("SELECT * FROM saving_records WHERE goalId = :goalId ORDER BY timestamp DESC")
    fun getRecordsForGoal(goalId: Long): Flow<List<SavingRecord>>
}
