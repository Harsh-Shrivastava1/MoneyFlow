package com.moneyflow.app.ui.theme

import android.graphics.Color

object AppColors {
    val Purple80 = Color.parseColor("#FFB0BCFF")
    val PurpleGrey80 = Color.parseColor("#FFCCC2DC")
    val Pink80 = Color.parseColor("#FFEFB8B8")

    val Purple40 = Color.parseColor("#FF6650A4")
    val PurpleGrey40 = Color.parseColor("#FF625B71")
    val Pink40 = Color.parseColor("#FF7D5260")
}
