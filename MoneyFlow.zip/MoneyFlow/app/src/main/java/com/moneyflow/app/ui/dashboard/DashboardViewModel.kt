package com.moneyflow.app.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.moneyflow.app.data.repository.ExpenseRepository
import com.moneyflow.app.data.repository.GoalRepository
import com.moneyflow.app.ui.base.BaseViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class DashboardViewModel(
    private val expenseRepository: ExpenseRepository,
    private val goalRepository: GoalRepository
) : BaseViewModel() {

    // TOTAL EXPENSE (Flow<Double?>)
    val totalExpense: StateFlow<Double> =
        expenseRepository.totalExpense
            .map { it ?: 0.0 }   // convert null -> 0
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = 0.0
            )

    // TOTAL SAVINGS (Flow<List<SavingGoal>>)
    val totalSavings: StateFlow<Double> =
        goalRepository.allGoals
            .map { goals ->
                goals.sumOf { it.savedAmount }   // NON-NULL
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = 0.0
            )

    // SMART INSIGHT
    val smartInsight: StateFlow<String> =
        expenseRepository.allExpenses
            .combine(totalExpense) { expenses, _ ->

                if (expenses.isEmpty()) {
                    "Start adding expenses to see smart insights!"
                } else {
                    val highestCategory = expenses
                        .groupBy { it.category }
                        .maxByOrNull { entry -> entry.value.sumOf { it.amount } }
                        ?.key ?: "General"

                    "You've spent the most on $highestCategory. Manage wisely!"
                }
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = "Loading insights..."
            )
}

class DashboardViewModelFactory(
    private val expenseRepository: ExpenseRepository,
    private val goalRepository: GoalRepository
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DashboardViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return DashboardViewModel(expenseRepository, goalRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
