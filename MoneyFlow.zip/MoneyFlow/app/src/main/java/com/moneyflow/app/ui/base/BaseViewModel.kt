package com.moneyflow.app.ui.base

import androidx.lifecycle.ViewModel

abstract class BaseViewModel : ViewModel() {
    // Common ViewModel logic can go here
}
